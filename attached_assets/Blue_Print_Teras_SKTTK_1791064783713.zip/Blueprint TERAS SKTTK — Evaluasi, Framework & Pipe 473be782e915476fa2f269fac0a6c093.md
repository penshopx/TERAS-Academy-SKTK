# Blueprint TERAS SKTTK — Evaluasi, Framework & Pipeline Agentic AI (Hermes · OpenClaw · MultiClaw)

<aside>
🧭

**Ringkasan keputusan:** TERAS SKTTK sudah punya filosofi yang kuat (evidence-based, safety gate, Capability Passport). Perbaikan terbesar bukan menambah banyak chatbot, tetapi: (1) mengikat seluruh konten ke struktur resmi SKTTK & SKKNI, (2) memisahkan **logika keputusan deterministik** (skor, safety gate, readiness) dari **agen LLM** (menjelaskan, melatih, mensimulasikan), dan (3) menjalankan agen spesialis sebagai armada **MultiClaw** dengan **Hermes** sebagai orkestrator dan **OpenClaw** sebagai gateway kanal.

</aside>

## 1. Evaluasi Aplikasi Saat Ini

Catatan cakupan: evaluasi berdasarkan halaman publik (landing). Fitur di balik login belum bisa diperiksa.

### 1.1 Kekuatan

| Aspek | Temuan | Nilai |
| --- | --- | --- |
| Positioning | "Build Competence. Build Evidence. Build Readiness." — fokus kesiapan, bukan sekadar latihan soal | Kuat, beda dari bank soal biasa |
| Alur belajar | Diagnostic → Learning → Practice → Evidence → Simulation → Readiness | Sudah selaras dengan logika asesmen kompetensi |
| Safety philosophy | Gagal kriteria keselamatan kritis = readiness diblokir, tidak bisa ditutup rata-rata skor | Sangat tepat untuk ketenagalistrikan |
| Capability Passport | Rekam jejak longitudinal tanpa menghapus percobaan & gap | Fondasi data yang bagus untuk agen |
| Narasi pasar | Data IEA WEE 2025, transisi energi, horizon 2046 | Meyakinkan untuk B2B/pemerintah |

### 1.2 Gap & Risiko

| # | Gap | Dampak | Rekomendasi |
| --- | --- | --- | --- |
| 1 | Struktur SKTTK resmi belum tampak (bidang, subbidang, jenis usaha, jabatan, kualifikasi/level, LSK) | Pengguna tidak tahu skema mana yang disiapkan | Tambahkan **Katalog Skema**: Bidang (Pembangkitan, Transmisi, Distribusi, Instalasi Pemanfaatan) × Jenis Usaha (Konsultansi, Pembangunan & Pemasangan, Pemeriksaan & Pengujian, Pengoperasian, Pemeliharaan) × Jabatan × Level |
| 2 | Contoh hanya Solar PV Installation | Terkesan hanya EBT/PLTS | Tampilkan 3–5 skema prioritas (mis. instalasi pemanfaatan TR, distribusi TM/TR, PLTS) |
| 3 | Dasar regulasi tidak disebut | Kredibilitas berkurang | Cantumkan rujukan Permen ESDM 6/2021 tentang SKTTK & SKKNI terkait, dengan versi dan tanggal verifikasi |
| 4 | Tidak ada disclaimer status | Risiko salah paham "ini sertifikasi resmi" | Tegaskan: TERAS = persiapan; sertifikat resmi diterbitkan LSK terakreditasi |
| 5 | Bahasa campur Inggris–Indonesia | Teknisi lapangan bisa bingung | Bahasa Indonesia utama; istilah Inggris sebagai sub-label |
| 6 | Tidak ada uji coba tanpa daftar | Konversi rendah | Mini-diagnostic 5 menit tanpa login → hasil singkat → ajakan daftar |
| 7 | Trust signal minim | B2B ragu | Tampilkan asesor/pakar reviewer, mitra LSK/perusahaan, metodologi penilaian |
| 8 | Crawler cepat gagal memuat (respons 500 / konten kosong), baru terbaca dengan render penuh | SEO & preview tautan buruk | Pre-render/SSR landing, meta tag & Open Graph, cek health endpoint Replit |
| 9 | Title ("Build Evidence") dan hero tidak konsisten | Kecil, tapi terlihat kurang rapi | Seragamkan tagline |
| 10 | Peran AI belum dijelaskan | Nilai unik Agentic AI tidak terlihat | Tampilkan "Tim Agen TERAS" (Tutor, Simulasi Asesor, Reviewer Bukti, Coach) |

### 1.3 Risiko desain Agentic AI yang harus diantisipasi

- **LLM tidak boleh memutuskan readiness sendirian.** Skor, safety gate, dan status siap dihitung oleh rule engine; agen hanya menjelaskan dan merekomendasikan.
- **Halusinasi teknis = risiko keselamatan.** Semua jawaban teknis wajib grounded ke Paket Pengetahuan (SKKNI, PUIL, SOP K3) dengan sitasi.
- **Isolasi data peserta.** Hermes dan OpenClaw dirancang sebagai agen personal; untuk aplikasi multi-peserta, memori harus dipisah per peserta dan akses lintas agen dibatasi.
- **Skill yang "self-improving" perlu gerbang review.** Skill baru hasil Hermes tidak langsung dipakai produksi sebelum direview pakar.

## 2. Arsitektur Target

### 2.1 Peran tiga lapis framework

| Lapis | Komponen | Fungsi di TERAS | Catatan konfigurasi |
| --- | --- | --- | --- |
| Orkestrasi & pembelajaran | **Hermes Agent** (Nous Research) | Orkestrator "Kepala Akademi": klasifikasi intent, memanggil agen spesialis (subagent), memori jangka panjang per peserta, jadwal (cron) pengingat & laporan | Learning loop dipakai untuk usulan skill; promosi skill lewat review manusia. Integrasi tool via MCP |
| Gateway & routing kanal | **OpenClaw** | Menghubungkan WhatsApp/Telegram/web ke agen yang tepat lewat *bindings*; tiap agen punya workspace sendiri ([SOUL.md](http://SOUL.md), [AGENTS.md](http://AGENTS.md)), skill allowlist, session store terpisah | Batasi akses lintas agen (`tools.agentToAgent.allow`), memori per agen, gateway terpisah untuk isolasi ketat |
| Armada spesialis | **MultiClaw** | Kumpulan agen spesialis = Template Peran + Paket Pengetahuan + Aturan | Satu template untuk banyak skema, bukan satu bot per skema |
| Inti deterministik | **TERAS Core** (backend app) | Rule engine, CAT/tryout, skor, safety gate, Capability Passport, audit log | Sumber kebenaran; agen membaca/menulis lewat API ber-izin |

### 2.2 Diagram arsitektur

```mermaid
flowchart TB
  subgraph CH[Kanal]
    WEB[Web App TERAS]
    WA[WhatsApp / Telegram]
  end
  WEB --> API[TERAS Core API]
  WA --> OC[OpenClaw Gateway<br/>bindings & routing]
  OC --> H
  API --> H[Hermes Orchestrator<br/>Kepala Akademi]
  H --> G1[Guardrail Input<br/>PII, topik, keamanan]
  G1 --> R{Router Intent}
  R --> A1[Diagnostik]
  R --> A2[Tutor KUK]
  R --> A3[Bank Soal & Tryout]
  R --> A4[K3 & Safety Gate]
  R --> A5[Simulasi Asesor]
  R --> A6[Reviewer Evidence]
  R --> A7[Remediasi]
  R --> A8[Readiness & Passport]
  R --> A9[Admin Persyaratan LSK]
  A1 & A2 & A3 & A4 & A5 & A6 & A7 & A8 & A9 --> V[Verifier / QA Agent<br/>sitasi & konsistensi]
  V --> OUT[Respons ke peserta]
  subgraph CORE[TERAS Core - deterministik]
    RE[Rule Engine & Safety Gate]
    CAT[CAT / Tryout Engine]
    PP[Capability Passport]
    KB[(Paket Pengetahuan<br/>SKKNI, PUIL, SOP K3)]
    VDB[(Vector DB)]
  end
  A2 & A4 & A5 --> KB
  KB --> VDB
  A3 --> CAT
  A4 & A8 --> RE
  A6 & A8 --> PP
```

## 3. Armada Agen Spesialis (MultiClaw)

| # | Agen | Tugas utama | Input | Output | Boleh memutuskan? |
| --- | --- | --- | --- | --- | --- |
| 0 | **Hermes – Kepala Akademi** | Routing, menjaga konteks peserta, delegasi, ringkasan progres | Pesan, profil, passport | Rencana tindakan, panggilan agen | Tidak (koordinator) |
| 1 | Diagnostik & Pemetaan Skema | Profil pengalaman → rekomendasi bidang/jabatan/level; pretest adaptif | CV, pengalaman kerja, pretest | Peta gap per unit/KUK | Rekomendasi saja |
| 2 | Kurator Regulasi & SKKNI (back-office) | Ekstraksi unit–elemen–KUK, versi regulasi, deteksi perubahan | Dokumen resmi JDIH/SKKNI | Draft Paket Pengetahuan | Tidak, wajib review pakar |
| 3 | Tutor KUK | Mengajar per KUK secara sokratik, contoh lapangan, sitasi | Gap, paket pengetahuan | Penjelasan, latihan mikro | Tidak |
| 4 | Generator & Kurator Soal | Membuat soal ber-tag KUK, level kognitif, tingkat kesulitan, pembahasan | Paket pengetahuan | Item soal draft | Tidak, wajib review + kalibrasi |
| 5 | Tryout & Feedback | Menjelaskan hasil tryout dari engine CAT | Hasil CAT | Pembahasan personal | Skor dari engine, bukan LLM |
| 6 | **K3 & Safety Gate** | Melatih & menguji kriteria kritis (isolasi listrik, LOTO, APD, bebas tegangan, pembumian kerja) | Jawaban/praktik peserta | Status kriteria kritis | Status ditetapkan rule engine |
| 7 | Simulasi Asesor | Role-play wawancara/verifikasi portofolio ala asesor LSK (teks/suara) | Skema, portofolio | Transkrip, catatan kelemahan | Tidak |
| 8 | Reviewer Evidence | Cek bukti terhadap prinsip valid, asli, terkini, memadai; analisis foto/dokumen | Unggahan bukti | Checklist & saran perbaikan | Rekomendasi; final oleh rule + reviewer |
| 9 | Remediasi & Coach | Rencana perbaikan, spaced repetition, pengingat terjadwal (cron Hermes) | Gap, jadwal | Rencana mingguan, nudges WA | Tidak |
| 10 | Readiness & Passport | Menyusun narasi readiness dan laporan dari data passport | Data passport, hasil rule | Laporan readiness | Status dari rule engine |
| 11 | Admin Persyaratan LSK | Checklist dokumen pendaftaran uji, panduan alur LSK | Profil, dokumen | Daftar kelengkapan | Tidak mengajukan atas nama peserta |
| 12 | Verifier / QA | Mengecek sitasi, konsistensi angka, bahasa aman, menolak jawaban tanpa sumber | Draft respons agen lain | Lolos / revisi | Ya, sebagai gerbang kualitas |

### 3.1 Struktur workspace agen (OpenClaw / Hermes)

```
agents/
  kepala-akademi/      SOUL.md  AGENTS.md  skills/[routing, ringkas-progres]
  tutor-kuk/           SOUL.md  AGENTS.md  skills/[ajar-kuk, cek-pemahaman]
  k3-safety-gate/      SOUL.md  AGENTS.md  skills/[skenario-isolasi, cek-apd]
  simulasi-asesor/     SOUL.md  AGENTS.md  skills/[wawancara, verifikasi-portofolio]
  reviewer-evidence/   SOUL.md  AGENTS.md  skills/[cek-vatm, analisis-foto]
  ...
shared/knowledge-packs/   (read-only, versioned)
```

### 3.2 Format Paket Pengetahuan SKTTK

```yaml
pack_id: GATRIK.<bidang>.<jenis_usaha>.<jabatan>.<level>
sector: GATRIK
version: 2026.1
sources:
  - regulation: "Permen ESDM 6/2021 (SKTTK)"
  - standard: "SKKNI <nomor/tahun>"
  - reference: "PUIL / SOP K3 terkait"
content:
  units: [ {unit_code, title, elements: [ {element, kuk: [...] } ] } ]
  critical_criteria: [KUK-xx, KUK-yy]   # memicu safety gate
  evidence_examples: [...]
  question_bank_ref: qb://<pack_id>
status: draft | review | active | retired
reviewed_by: "<asesor/pakar>"
verified_at: 2026-10-01
```

## 4. Framework Penilaian (Deterministik)

### 4.1 Model readiness

1. **Safety Gate dulu:** jika ada satu KUK kritis berstatus belum kompeten → status `BLOCKED`, apa pun skornya.
2. **Minimum per unit:** setiap unit wajib lulus ambang minimal (mis. ≥ 70) — rata-rata tidak menutupi unit lemah.
3. **Skor komposit** (bobot awal, dikalibrasi kemudian):

| Komponen | Bobot | Sumber |
| --- | --- | --- |
| Pengetahuan (tryout CAT) | 30% | CAT engine |
| Praktik / simulasi kasus | 25% | Skenario terstruktur |
| Evidence/portofolio | 25% | Reviewer Evidence + rule |
| Simulasi asesor | 20% | Rubrik terstruktur |

| Status | Aturan |
| --- | --- |
| BLOCKED | Ada KUK kritis gagal |
| NOT READY | Komposit < 70 atau ada unit di bawah ambang |
| NEEDS REASSESSMENT | Komposit ≥ 70 tetapi bukti/hasil > 6 bulan atau baru remediasi |
| READY | Komposit ≥ 80, semua unit lulus, semua KUK kritis kompeten |

### 4.2 Data model inti

| Entitas | Field kunci |
| --- | --- |
| `scheme` | bidang, subbidang, jenis_usaha, jabatan, level, pack_id |
| `unit` / `element` / `kuk` | kode, deskripsi, is_critical, versi |
| `item` (soal) | kuk_id, tipe, kesulitan, diskriminasi, status_review |
| `attempt` | learner_id, item/skenario, skor, waktu |
| `evidence` | learner_id, unit_id, file, status_vatm, reviewer |
| `gap` | learner_id, kuk_id, sumber, prioritas |
| `passport_event` | learner_id, tipe, payload, timestamp (append-only) |
| `agent_trace` | session, agen, tool, sumber_sitasi, verdict_QA |

## 5. Pipeline

### 5.1 Pipeline konten (Regulasi → Paket Pengetahuan)

```mermaid
flowchart LR
  P1[1. Kumpulkan regulasi & SKKNI resmi] --> P2[2. Agen Kurator ekstrak<br/>unit-elemen-KUK]
  P2 --> P3[3. Tandai KUK kritis K3]
  P3 --> P4[4. Generator soal &<br/>skenario per KUK]
  P4 --> P5[5. Review pakar/asesor]
  P5 --> P6[6. Uji coba & kalibrasi item]
  P6 --> P7[7. Publish paket versi baru]
  P7 --> P8[8. Monitor perubahan regulasi]
  P8 --> P1
```

### 5.2 Pipeline peserta (Learner Journey)

```mermaid
flowchart LR
  D[Diagnostik & pilih skema] --> L[Learning per gap<br/>Tutor KUK]
  L --> PR[Practice & skenario K3]
  PR --> EV[Evidence upload<br/>Reviewer]
  EV --> SIM[Tryout CAT +<br/>Simulasi Asesor]
  SIM --> SG{Safety Gate}
  SG -- gagal --> RM[Remediasi] --> PR
  SG -- lolos --> RD{Readiness}
  RD -- belum --> RM
  RD -- siap --> LSK[Checklist pendaftaran LSK]
  LSK --> PP[Capability Passport]
```

### 5.3 Pipeline runtime satu permintaan

1. Kanal (web/WA) → OpenClaw binding / Core API.
2. Guardrail input: PII, prompt injection, topik di luar cakupan.
3. Hermes memuat konteks peserta (passport ringkas + memori) dan mengklasifikasi intent.
4. Delegasi ke agen spesialis (subagent paralel bila perlu).
5. Agen memanggil tool: RAG Paket Pengetahuan, CAT engine, rule engine, passport API (via MCP).
6. Verifier QA: cek sitasi, angka, keselamatan; revisi atau tolak.
7. Respons + tulis `passport_event` dan `agent_trace`.

### 5.4 Pipeline learning loop & governance

```mermaid
flowchart LR
  T[Trace & pertanyaan tak terjawab] --> S[Hermes usulkan skill/FAQ baru]
  S --> RV[Review pakar]
  RV -- setuju --> ST[Staging + eval set]
  ST -- lulus --> PRD[Produksi]
  RV -- tolak --> X[Arsip]
```

### 5.5 Pipeline evaluasi (wajib sebelum rilis)

| Eval | Metrik | Target awal |
| --- | --- | --- |
| Akurasi teknis | Jawaban benar vs kunci pakar (golden set ≥ 200 pertanyaan/skema) | ≥ 95% |
| Grounding | Respons teknis bersitasi valid | 100% |
| Keamanan K3 | Respons berbahaya pada red-team set | 0 |
| Routing | Intent ke agen yang tepat | ≥ 90% |
| Prediktif | Korelasi status READY vs kelulusan uji LSK | Dipantau per kohort |

## 6. Rekomendasi Stack

| Lapisan | Pilihan |
| --- | --- |
| Frontend | Web app saat ini (Replit) + SSR/pre-render landing; PWA untuk lapangan |
| Core API | Node/TypeScript atau Python FastAPI; PostgreSQL + pgvector; antrian job (Redis) |
| Agent runtime | Hermes Agent di VPS/Docker sebagai orkestrator; OpenClaw Gateway untuk WA/Telegram; tool via MCP ke Core API |
| Model | Router multi-model (model besar untuk tutor/asesor, model kecil untuk klasifikasi & QA) |
| Observability | Tracing agen, biaya per sesi, dashboard eval |
| Keamanan | Isolasi memori per peserta, audit log, consent unggah bukti, enkripsi file |

## 7. Roadmap

| Fase | Durasi | Cakupan | Indikator selesai |
| --- | --- | --- | --- |
| 1. Fondasi | 4–6 minggu | Katalog skema, Paket Pengetahuan 1 skema pilot (mis. PLTS atau Instalasi Pemanfaatan TR), rule engine & safety gate, passport event log | Paket pilot direview pakar; golden set siap |
| 2. Agen inti | 4–6 minggu | Hermes + Tutor KUK + K3 Safety Gate + Tryout Feedback + Verifier | Eval akurasi ≥ 95%, 0 respons berbahaya |
| 3. Asesmen lanjut | 6 minggu | Simulasi Asesor (suara), Reviewer Evidence (vision), Remediasi & Coach via WhatsApp (OpenClaw) | Pilot 30–50 peserta |
| 4. Skala | berkelanjutan | 5+ skema, dashboard B2B perusahaan/PLN mitra, korelasi hasil LSK, learning loop dengan governance | Skema baru ≤ 2 minggu via pipeline konten |

## 8. Langkah Berikutnya

- [ ]  Pilih 1 skema pilot dan kumpulkan dokumen resmi (Permen ESDM 6/2021, SKKNI terkait, SOP K3).
- [ ]  Tetapkan daftar KUK kritis (safety gate) bersama asesor.
- [ ]  Pisahkan logika skor/readiness ke rule engine di Core.
- [ ]  Buat golden set evaluasi 200 pertanyaan untuk skema pilot.
- [ ]  Siapkan workspace agen ([SOUL.md](http://SOUL.md), [AGENTS.md](http://AGENTS.md), skills) untuk 5 agen inti.
- [ ]  Perbaiki landing: katalog skema, disclaimer, mini-diagnostic, SSR/SEO.
- [ ]  Selaraskan dengan [Arsitektur Multi-Sektor & Armada Agen Spesialis Gustafta](https://app.notion.com/p/Arsitektur-Multi-Sektor-Armada-Agen-Spesialis-Gustafta-09c80368b6ea4a6aaff9f71599c9cb43?pvs=21) (Paket Sektor Ketenagalistrikan & EBT).

<aside>
⚠️

Rincian bidang, jenis usaha, jabatan, dan level SKTTK pada dokumen ini adalah peta awal. Verifikasi ke regulasi terbaru di JDIH ESDM dan LSK sebelum dipakai rule engine.

</aside>